package com.example.sireesharmi.imdb;

import android.app.Activity;
import android.os.Bundle;
import android.os.PersistableBundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

/**
 * Created by Sireesharmi on 12-11-2016.
 */
public class Third extends Activity {
    EditText code;
    EditText thirdnum;
    Button thirdrate;
    TextView show;
    int  avg1=5,avg2=5,avg3=5,avg4=5;
    @Override
    public void onCreate(Bundle savedInstanceState, PersistableBundle persistentState) {
        super.onCreate(savedInstanceState, persistentState);
        setContentView(R.layout.third);

        show=(TextView)findViewById(R.id.showvalue);
        code=(EditText)findViewById(R.id.ecode);
        thirdnum=(EditText)findViewById(R.id.thirdnum);
        thirdrate=(Button)findViewById(R.id.thirdrate);

        thirdrate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String codenum=code.getText().toString();
                String codevalue=thirdnum.getText().toString();

                switch (codenum){
                    case "1":avg1=(avg1+Integer.parseInt(codevalue))/2;
                             show.setText("Rating for your movie is"+avg1);
                             break;
                    case "2":avg2=(avg2+Integer.parseInt(codevalue))/2;
                             show.setText("Rating for your movie is"+avg2);
                             break;
                    case "3":avg3=(avg3+Integer.parseInt(codevalue))/2;
                             show.setText("Rating for your movie is"+avg3);
                             break;
                    case "4":avg4=(avg4+Integer.parseInt(codevalue))/2;
                             show.setText("Rating for your movie is"+avg4);
                             break;
                    default:show.setText("RATE NOW!!!!");
                }
            }
        });
    }
}

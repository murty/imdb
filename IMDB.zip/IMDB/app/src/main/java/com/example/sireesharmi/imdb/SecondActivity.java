package com.example.sireesharmi.imdb;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.os.PersistableBundle;
import android.view.View;
import android.widget.Button;

/**
 * Created by Sireesharmi on 12-11-2016.
 */
public class SecondActivity extends Activity {
    Button watch;
    Button rate;
    @Override
    public void onCreate(Bundle savedInstanceState, PersistableBundle persistentState) {
        super.onCreate(savedInstanceState, persistentState);
        setContentView(R.layout.second);

        watch=(Button)findViewById(R.id.watch);
        rate=(Button)findViewById(R.id.rate);

        watch.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Uri.parse("https://youtube.com/rajini famous movies");
            }
        });

        rate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(SecondActivity.this,Third.class);
                startActivity(intent);
            }
        });
    }
}
